import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:flutter_mmnes/utils/image_utils.dart';
import 'package:flutter_mmnes/utils/toast.dart';

String _taskId;
String _dialogMessage = "下载中...";
enum ProgressDialogType { Normal, Download }

ProgressDialogType progressDialogType = ProgressDialogType.Normal;
double _progress = 0.0;
bool isShow = false;
String _localPath;
String _downloadUrl;
enum DownloadStatus { DOWNLOADING, FAIL, COMPLETE }

class DownloadProgressDialog {
  MyDialog _dialog;

  BuildContext _buildContext, _context;
  DownloadStatus downloadStatus;

  DownloadProgressDialog(
      BuildContext buildContext, ProgressDialogType progressDialogtype) {
    _buildContext = buildContext;

    progressDialogType = progressDialogtype;
  }

  void setMessage(String mess) {
    _dialogMessage = mess;
    debugPrint("ProgressDialog message changed: $mess");
  }

  void update(
      {String taskId,
        double progress,
        String message,
        String path,
        String url}) {
    debugPrint("ProgressDialog message changed: ");
    if (progressDialogType == ProgressDialogType.Download) {
      debugPrint("Old Progress: $progress, New Progress: $progress");
      _progress = progress;
    }
    if (progress == 100.0) {
      debugPrint("download complete");
      downloadStatus = DownloadStatus.COMPLETE;
    } else if (progress == -1.0) {
      downloadStatus = DownloadStatus.FAIL;
    } else {
      downloadStatus = DownloadStatus.DOWNLOADING;
    }
    debugPrint("Old message: $_dialogMessage, New Message: $message");
    _dialogMessage = message;
    _taskId = taskId;
    _localPath = path;
    _downloadUrl = url;
    _dialog.update(downloadStatus);
  }

  bool isShowing() {
    return isShow;
  }

  void hide() {
    if (isShow) {
      isShow = false;
      Navigator.of(_context).pop();
      debugPrint('ProgressDialog dismissed');
    }
  }

  void show() {
//    if (!isShow) {
//      _dialog = new MyDialog();
//      isShow = true;
//      debugPrint('ProgressDialog shown');
//      showDialog<dynamic>(
//        context: _buildContext,
//        barrierDismissible: false,
//        builder: (BuildContext context) {
//          _context = context;
//          return Dialog(
//              backgroundColor: Colors.transparent,
//              insetAnimationDuration: Duration(milliseconds: 100),
//              child: _dialog);
//        },
//      );
//    }
  }
}

// ignore: must_be_immutable
class MyDialog extends StatefulWidget {
  var _dialog = new MyDialogState(_downloadStatus);
  static DownloadStatus _downloadStatus;

  update(DownloadStatus downloadStatus) {
    _downloadStatus = downloadStatus;
    _dialog.changeState();
  }

  @override
  // ignore: must_be_immutable
  State<StatefulWidget> createState() {
    return _dialog;
  }
}

class MyDialogState extends State<MyDialog> {
  DownloadStatus _downloadStatus;

  MyDialogState(this._downloadStatus);

  changeState() {
    setState(() {});
  }

  @override
  void dispose() {
    super.dispose();
    isShow = false;
    debugPrint('ProgressDialog dismissed by back button');
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        height: getDialogHeightByDesc(context) + 75,
        width: MediaQuery.of(context).size.width * 0.95,
        child: Column(children: <Widget>[
          Stack(children: <Widget>[
            bgImageView(context),
            Container(
              height: getDialogHeightByDesc(context),
              width: MediaQuery.of(context).size.width * 0.95,
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Column(children: <Widget>[
                      Container(
                          child: Text(_dialogMessage,
                              style: TextStyle(
                                  color: Colors.black87,
                                  fontSize: 16.0,
                                  fontWeight: FontWeight.w700)),
                          padding: EdgeInsets.only(top: 16, left: 16),
                          alignment: Alignment.center),
                      Padding(
                          padding: const EdgeInsets.all(12.0),
                          //进度条
                          child: _progress == 100.0
                              ? FlatButton(
                              onPressed: () => openDownloadFile(context),
                              child: Stack(
                                alignment: Alignment.center,
                                children: <Widget>[
                                  loadAssetImage("startask/dd_btn_bg",
                                      width: 126, height: 35),
                                  new Text(
                                    "打开",
                                    style: new TextStyle(
                                      fontSize: 14,
                                      color: Color(0xFFfefeff),
                                    ),
                                  ),
                                ],
                              ))
                              : new SizedBox(
                            //限制进度条的高度
                            height: 6.0,
                            //限制进度条的宽度
                            width: 200,
                            child: new LinearProgressIndicator(
                              //0~1的浮点数，用来表示进度多少;如果 value 为 null 或空，则显示一个动画，否则显示一个定值
                                value: _progress / 100,
                                //背景颜色
                                backgroundColor: Colors.blueGrey[100],
                                //进度颜色
                                valueColor:
                                new AlwaysStoppedAnimation<Color>(
                                    Colors.blueAccent)),
                          )),
                    ]),
                  ]),
            ),
          ]),
          SizedBox(
            height: 25,
          ),
          FlatButton(
              onPressed: () => Navigator.pop(context),
              child:
              loadAssetImage("startask/icon_close", width: 35, height: 35)),
        ]));
  }

  bgImageView(BuildContext context) {
    return Container(
      decoration: ShapeDecoration(
        color: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(
            8.0,
          )),
        ),
      ),
      height: getDialogHeightByDesc(context),
      width: MediaQuery.of(context).size.width * 0.95,
      child: new Stack(
        children: <Widget>[
          new Positioned(
            child: loadAssetImage("startask/bg_messagebox",
                width: MediaQuery.of(context).size.width * 0.95,
                height: getDialogHeightByDesc(context),
                fit: BoxFit.cover),
          ),
        ],
      ),
    );
  }

  double getDialogHeightByDesc(BuildContext context) {
    return MediaQuery.of(context).size.height * 0.2;
  }

  openDownloadFile(BuildContext context) {
    Navigator.pop(context);
    // 打开文件:android手机调用原生方法安装apk，其他平台直接调用openFile
    if (_downloadUrl.contains(".apk")) {
      installApk(_taskId);
    } else {
      _openDownloadedFile(_taskId).then((success) {
        if (!success) {
          Scaffold.of(context)
              .showSnackBar(SnackBar(content: Text('Cannot open this file')));
        }
      });
    }
  }
}

void installApk(String taskId) {
  //根据localpath和url构造出下载文件路径
  //"https://ycy.aplusunion.com/group1/M00/00/00/CgEFeVwJ3vaAJi6DAExQliFJFSo441.apk"
  int index = _downloadUrl.lastIndexOf("/");
  String apkName = _downloadUrl.substring(index + 1);
  String filePath = _localPath + "/" + apkName;
  print("installApk apkName:" + apkName + "--filePath:" + filePath);
//  InstallApkPlugin.installApk(filePath);
}

// 根据taskId打开下载文件
Future<bool> _openDownloadedFile(taskId) {
  return FlutterDownloader.open(taskId: taskId);
}
